# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'connect_me.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!
#导入程序运行必须模块
import sys
from PyQt5.QtWidgets import QMessageBox#这是弹出对话框需要的库
#PyQt5中使用的基本控件都在PyQt5.QtWidgets模块中
from PyQt5.QtWidgets import QApplication, QMainWindow
#导入designer工具生成的login模块
from test2 import Ui_Form
from wuziqi2 import *
import pygame





class MyMainForm(QMainWindow, Ui_Form):
    def __init__(self, parent=None):
        super(MyMainForm, self).__init__(parent)
        self.setupUi(self)
        self.start_button.clicked.connect(self.display)
        self.exit_button.clicked.connect(self.close)
        self.help_button.clicked.connect(self.showMsg)
    def display(self):

        pygame.mixer.music.pause()#关闭音乐
        pg.mixer.music.load('2.mp3')#播放游戏背景音乐
        pg.mixer.music.set_volume(0.1)
        pg.mixer.music.play(-1, 0)

        game = Gomoku()#开始运行游戏
        game.main()
    def showMsg(self):
        a = open('帮助.txt', 'r', encoding='utf-8')
        a.seek(0, 0)
        QMessageBox.information(None,"帮助",a.read())
        a.close()


if __name__ == "__main__":
    #固定的，PyQt5程序都需要QApplication对象。sys.argv是命令行参数列表，确保程序可以双击运行
    app = QApplication(sys.argv)
    #初始化
    myWin = MyMainForm()
    #将窗口控件显示在屏幕上
    myWin.show()
    #程序运行，sys.exit方法确保程序完整退出。
    sys.exit(app.exec_())